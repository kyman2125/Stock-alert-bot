#!/bin/bash
python3 stock_bot.py
