#!/bin/bash
python stock_bot.py
